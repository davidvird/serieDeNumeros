//: serie de numeros del 0 al 100 con reglas de evaluación de cada numero

import UIKit

var numeros = 1...100


print("0")

for n in numeros {
    
// print(n)

    if n%5 == 0 {
        print("\(n) Bingo")
    }
    
    if n%2 == 0 {
        print("\(n) Par")
    }
    
    if n >= 30 && n <= 40 {
        print("\(n) Viva Swift")
    }
    
    if n%2 > 0 && n%2 <= 1 {
        print("\(n) Impar")
    }
    
    print("")

}
